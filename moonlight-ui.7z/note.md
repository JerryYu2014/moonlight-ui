# Note

- [vzer-ui](https://github.com/zengjielin/vzer-ui)

## 滚动条

- [CSS3自定义滚动条样式](https://www.cnblogs.com/ranyonsue/p/9487599.html)
- [关于 element-ui 的隐藏组件el-scrollbar](https://segmentfault.com/a/1190000019325694?utm_source=tag-newest)

## 富文本编辑器

- [人人都会写的富文本编辑器](https://segmentfault.com/a/1190000010572792)
- [document.execCommand](https://developer.mozilla.org/zh-CN/docs/Web/API/Document/execCommand)
- [contenteditable](https://developer.mozilla.org/zh-CN/docs/Web/HTML/Global_attributes/contenteditable)
- [vm-editor](https://github.com/luosijie/vm-editor)
- [JS编写自己的富文本编辑器](https://www.cnblogs.com/jiangcheng-langzi/p/7778254.html)

## 时间日期选择器


## vue的命名限制

- [[Vue warn]: Do not use built-in or reserved HTML elements as component id:](https://www.jianshu.com/p/97668b6fd90d)
