// 打包时使用的scss总入口

require('./assets/scss/index.scss')
